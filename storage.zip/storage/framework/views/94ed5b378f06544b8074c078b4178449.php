<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

<div class="about_area about_bg">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="about_page">
                    <h3>our services</h3>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="about_container">
    <div id="about_elements" class="container mt-5" style="padding-top:0%">
        <div class="about_heading">
            
        </div>
        <div id="service_para" class="about_para">
            <p id="service_content">Who understands the security challenges of customers better than their true service
                partner?</p>
        </div>
        <div id="service_text" class="about_text">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quam possimus perspiciatis dolores sunt magnam
                sint
                dolorum vel, voluptas adipisci voluptatibus! Praesentium odit officia doloremque illum. Amet eligendi
                ducimus culpa odio aut repellendus optio cupiditate provident repudiandae nobis perspiciatis iure
                quaerat
                ratione aliquam nulla enim dolore esse, tempore odit illum! Itaque?</p>
        </div>
    </div>
</div>

<div class="values_container container mt-5">
    <div class="values_elements">
        <h2 id="values_title">our services</h2>
        <div id="values_box" class="row">
            <div class="col-lg-6">
                <div class="values_icon">
                    <img src="<?php echo e(asset('assets/image/icons8-award-100.png')); ?>" alt="" style="width: 25%">
                </div>
                <div class="values_heading">
                    <h2 id="servie_heading_1">epass</h2>
                </div>
                <div class="values_para">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor quaerat aliquid dolorum
                        voluptatem
                        quibusdam ex nam eligendi repellendus unde, quas facilis. Dolor voluptate aperiam rerum vitae
                        exercitationem modi doloremque harum.</p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="values_icon">
                    <img src="<?php echo e(asset('assets/image/icons8-shield-64.png')); ?>" alt="" style="width: 25%">
                </div>
                <div class="values_heading">
                    <h2 id="service_heading_2">system interprises</h2>
                </div>
                <div class="values_para">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor quaerat aliquid dolorum
                        voluptatem
                        quibusdam ex nam eligendi repellendus unde, quas facilis. Dolor voluptate aperiam rerum vitae
                        exercitationem modi doloremque harum.</p>
                </div>
            </div>
        </div>

        <div id="values_box" class="row">
            <div class="col-lg-6">
                <div class="values_icon">
                    <img src="<?php echo e(asset('assets/image/icons8-cogs-64.png')); ?>" alt="" style="width: 25%">
                </div>
                <div class="values_heading">
                    <h2 id="service_heading_3">development & collaboration</h2>
                </div>
                <div class="values_para">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor quaerat aliquid dolorum
                        voluptatem
                        quibusdam ex nam eligendi repellendus unde, quas facilis. Dolor voluptate aperiam rerum vitae
                        exercitationem modi doloremque harum.</p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="values_icon">
                    <img src="<?php echo e(asset('assets/image/icons8-handshake-64.png')); ?>" alt="" style="width: 25%">
                </div>
                <div class="values_heading">
                    <h2 id="service_heading_4">ex-man security services</h2>
                </div>
                <div class="values_para">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor quaerat aliquid dolorum
                        voluptatem
                        quibusdam ex nam eligendi repellendus unde, quas facilis. Dolor voluptate aperiam rerum vitae
                        exercitationem modi doloremque harum.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="about_moreInfo">
        <div class="about_img">
            <img src="<?php echo e(asset('assets/image/Security-guard-1.jpg')); ?>" alt="">
        </div>
        <div class="about_morePara">
            <h2>excellent sparate services</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam ut explicabo sapiente, ipsam dolor
                dolorem,
                quis error voluptates aperiam eaque laboriosam at ipsa alias officiis illum nesciunt, provident facere
                doloribus?</p>
            
        </div>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ESS-Laravel\resources\views/Frontend/services.blade.php ENDPATH**/ ?>